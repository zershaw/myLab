package com.baizhi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDay7Application {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootDay7Application.class, args);
    }

}
